import { motion } from 'framer-motion'
import { Bot, Users, ArrowRight } from 'lucide-react'
import SlideFrame, { SlideHeader } from '../SlideFrame'

export default function Slide05_BeyondAI() {
  return (
    <SlideFrame>
      <SlideHeader
        eyebrow="Beyond AI · Back to Basics"
        title="The Burbank advantage."
        presenter="jim"
      />

      {/* Two-column compare */}
      <div className="grid grid-cols-1 md:grid-cols-[1fr_auto_1fr] gap-8 lg:gap-10 items-stretch flex-1 content-center">
        {/* Synthetic */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.4, duration: 0.7 }}
          className="glass rounded-2xl p-8 lg:p-10 border border-white/8 relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-32 h-32 rounded-full bg-red-500/5 blur-3xl" />
          <div className="relative">
            <div className="flex items-center gap-2.5 mb-6">
              <Bot className="h-5 w-5 text-white/40" />
              <span className="text-sm uppercase tracking-[0.2em] text-white/45 font-semibold">The race to the bottom</span>
            </div>
            <div className="font-serif text-3xl lg:text-4xl text-white/85 mb-6 leading-tight">
              The internet is flooding with cheap, synthetic AI spam.
            </div>
            <ul className="space-y-3 text-white/65 text-lg">
              <li className="flex gap-3"><span className="text-white/30 mt-1">—</span><span>SEO is dying</span></li>
              <li className="flex gap-3"><span className="text-white/30 mt-1">—</span><span>Digital trust is plummeting</span></li>
              <li className="flex gap-3"><span className="text-white/30 mt-1">—</span><span>Content commodity prices crashing</span></li>
            </ul>
          </div>
        </motion.div>

        {/* Arrow connector */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.9, duration: 0.6 }}
          className="hidden md:flex flex-col items-center justify-center"
        >
          <div className="text-sm uppercase tracking-[0.3em] text-white/40 mb-3 rotate-90 origin-center whitespace-nowrap">
            Therefore
          </div>
          <ArrowRight className="h-7 w-7 text-accent-cyan" />
        </motion.div>

        {/* Authentic */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.7, duration: 0.7 }}
          className="gradient-border p-8 lg:p-10 relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-32 h-32 rounded-full bg-accent-cyan/10 blur-3xl" />
          <div className="relative">
            <div className="flex items-center gap-2.5 mb-6">
              <Users className="h-5 w-5 text-accent-cyan" />
              <span className="text-sm uppercase tracking-[0.2em] text-accent-cyan font-semibold">The premium good</span>
            </div>
            <div className="font-serif text-3xl lg:text-4xl text-white mb-6 leading-tight">
              Authentic local connection becomes a <em className="gradient-text">premium</em> commodity.
            </div>
            <ul className="space-y-3 text-white/80 text-lg">
              <li className="flex gap-3"><span className="text-accent-cyan/70 mt-1">+</span><span>Physical storefronts</span></li>
              <li className="flex gap-3"><span className="text-accent-cyan/70 mt-1">+</span><span>Local partnerships</span></li>
              <li className="flex gap-3"><span className="text-accent-cyan/70 mt-1">+</span><span>Community hubs &amp; Chamber events</span></li>
            </ul>
          </div>
        </motion.div>
      </div>

      {/* Closer */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.3, duration: 0.7 }}
        className="text-center mt-10"
      >
        <div className="font-serif italic text-3xl lg:text-4xl text-white/85">
          You cannot automate a handshake.
        </div>
      </motion.div>
    </SlideFrame>
  )
}
