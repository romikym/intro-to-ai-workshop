import { motion } from 'framer-motion'
import { Brain, Dumbbell, Compass } from 'lucide-react'
import SlideFrame, { SlideHeader } from '../SlideFrame'

export default function Slide04_WorkforceReadiness() {
  return (
    <SlideFrame>
      <SlideHeader
        eyebrow="Workforce Readiness"
        title="The skill is not generation."
        presenter="jim"
      />

      <div className="flex-1 flex flex-col justify-center">
        {/* Big punchline */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.8 }}
          className="text-center mb-14"
        >
          <div className="font-serif text-4xl sm:text-5xl lg:text-6xl text-white/95 leading-[1.1] max-w-5xl mx-auto">
            The future workforce does not need to know how to <em className="text-white/55">generate</em> AI content.
            <br className="hidden sm:block" />
            <span className="gradient-text"> They need the critical thinking to audit it.</span>
          </div>
        </motion.div>

        {/* Three supporting points */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card
            icon={Dumbbell}
            title="Atrophy is real"
            body="Outsource problem-solving to AI and the corporate muscle for innovation atrophies. Same way digital lobbies degrade physical social skills."
            delay={0.8}
          />
          <Card
            icon={Brain}
            title="Where AI shines"
            body="Formatting, summarizing internal transcripts, overcoming the blank page. Tactical, internal, low-stakes work."
            delay={1.0}
          />
          <Card
            icon={Compass}
            title="Human is the driver"
            body="The human judgment stays in the seat. AI is the engine, not the navigator."
            delay={1.2}
          />
        </div>
      </div>
    </SlideFrame>
  )
}

function Card({ icon: Icon, title, body, delay }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.7 }}
      className="glass rounded-2xl p-8 border border-white/8 hover:border-white/20 transition-colors"
    >
      <div className="h-12 w-12 rounded-lg bg-gradient-to-br from-accent-cyan/15 to-accent-blue/5 border border-accent-cyan/15 flex items-center justify-center mb-5">
        <Icon className="h-6 w-6 text-accent-cyan" />
      </div>
      <div className="font-serif text-2xl lg:text-3xl text-white/95 mb-3 leading-tight">{title}</div>
      <div className="text-white/65 leading-relaxed text-lg">{body}</div>
    </motion.div>
  )
}
