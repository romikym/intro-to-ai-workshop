import { motion } from 'framer-motion'
import SlideFrame, { SlideHeader } from '../SlideFrame'
import TokenPrediction from '../TokenPrediction'

export default function Slide03_WhatAIIs() {
  return (
    <SlideFrame>
      <SlideHeader
        eyebrow="What AI Is"
        title="It does not know things."
        presenter="jim"
      />

      <div className="grid grid-cols-1 lg:grid-cols-[1.1fr_1fr] gap-12 lg:gap-16 flex-1 items-center">
        {/* Live token prediction demo */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.4, duration: 0.8 }}
          className="glass-strong rounded-2xl p-8 lg:p-10 border border-white/10"
        >
          <TokenPrediction />
        </motion.div>

        {/* Argument */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.6, duration: 0.8 }}
          className="space-y-7"
        >
          <Point delay={0.8}>
            An <span className="font-serif italic text-accent-cyan">LLM</span> predicts the next most likely word based on massive scraped training data. Built to sound confident — not to be accurate.
          </Point>

          <Point delay={1.0}>
            Using it as a search engine or factual checker exposes a small business to <span className="text-accent-cyan font-medium">massive liability</span>.
          </Point>

          <Point delay={1.2}>
            It predicts the <span className="font-serif italic">statistical middle</span>. Therefore AI guarantees <span className="font-serif italic gradient-text">average</span> output.
          </Point>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.5, duration: 0.6 }}
            className="pt-5 mt-3 border-t border-white/10"
          >
            <div className="font-serif text-3xl lg:text-4xl text-white/95 leading-tight">
              Average kills <br/>
              <span className="italic gradient-text">local brands.</span>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </SlideFrame>
  )
}

function Point({ children, delay }) {
  return (
    <motion.p
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.6 }}
      className="text-xl lg:text-2xl text-white/85 leading-relaxed"
    >
      {children}
    </motion.p>
  )
}
