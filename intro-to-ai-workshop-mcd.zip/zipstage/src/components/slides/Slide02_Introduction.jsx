import { motion } from 'framer-motion'
import { Zap, Droplets, Cpu, Wrench } from 'lucide-react'
import SlideFrame, { SlideHeader, PointCard } from '../SlideFrame'

export default function Slide02_Introduction() {
  const points = [
    {
      icon: Cpu,
      headline: '"Adopt AI or Die"',
      body: 'Tech platforms push the narrative because they need you dependent on it.'
    },
    {
      icon: Zap,
      headline: 'Not magic. Software.',
      body: 'A brutally resource-intensive piece of software that costs serious money and energy to run.'
    },
    {
      icon: Droplets,
      headline: 'Real physical costs',
      body: 'Each generative query consumes exponentially more compute, electricity, and fresh water for cooling than a search.'
    },
    {
      icon: Wrench,
      headline: 'Oracle → Tool',
      body: 'Stop asking it for answers. Start using it as an instrument that requires a skilled operator.'
    }
  ]

  return (
    <SlideFrame>
      <SlideHeader
        eyebrow="Introduction"
        title="Look behind the curtain."
        presenter="jim"
      />

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 lg:gap-7 flex-1 items-stretch content-center">
        {points.map((p, i) => {
          const Icon = p.icon
          return (
            <PointCard key={i} delay={0.2 + i * 0.1}>
              <div className="flex items-start gap-5">
                <div className="h-14 w-14 rounded-xl bg-gradient-to-br from-accent-cyan/15 to-accent-blue/10 border border-accent-cyan/20 flex items-center justify-center shrink-0">
                  <Icon className="h-6 w-6 text-accent-cyan" />
                </div>
                <div>
                  <div className="font-serif text-3xl text-white/95 mb-3 leading-tight">
                    {p.headline}
                  </div>
                  <div className="text-white/70 leading-relaxed text-lg">
                    {p.body}
                  </div>
                </div>
              </div>
            </PointCard>
          )
        })}
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.2, duration: 0.8 }}
        className="mt-10 text-center text-lg text-white/50 italic font-serif"
      >
        Evaluate it by its true physical and operational costs — not by the marketing.
      </motion.div>
    </SlideFrame>
  )
}
