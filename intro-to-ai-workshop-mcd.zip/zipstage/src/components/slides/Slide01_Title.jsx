import { motion } from 'framer-motion'

/**
 * Slide 01 — Title.
 *
 * Aesthetic: Apple keynote opener × Media City Design × TRON.
 * Inter Tight headline at stadium scale, italic Fraunces accent word,
 * electric blue → violet gradient. The TronGrid backdrop does the
 * atmospheric heavy lifting; this slide is mostly typography breathing
 * inside the perspective grid.
 *
 * Flynn's manifesto floats below the fold as a small dedication.
 */
export default function Slide01_Title() {
  return (
    <div className="w-full h-full flex flex-col items-center justify-center px-8 sm:px-14 py-12 lg:py-16 relative">
      {/* Hero text block */}
      <div className="text-center z-10 max-w-[1400px] flex-shrink-0">
        <motion.div
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
          className="text-stage-eyebrow text-accent-cyan mb-8 font-sans"
        >
          Burbank Chamber · 2026
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.55, duration: 1.1, ease: [0.22, 1, 0.36, 1] }}
          className="font-sans display-sans gradient-text-bright text-stage-hero mb-7"
        >
          Introduction to{' '}
          <span className="display-serif gradient-electric" style={{ fontStyle: 'italic' }}>
            AI<span className="text-white/40 not-italic">.</span>
          </span>
        </motion.h1>

        <motion.div
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.0, duration: 0.85 }}
          className="font-sans display-sans text-stage-sub text-white/95 mb-5"
        >
          Cutting through{' '}
          <span className="display-serif gradient-electric" style={{ fontStyle: 'italic' }}>the noise</span>.
        </motion.div>

        <motion.p
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.3, duration: 0.85 }}
          className="text-stage-body text-white/65 max-w-3xl mx-auto"
        >
          Thirty minutes. What it is, what it isn't, and what to do this week.
        </motion.p>
      </div>

      {/* Presenters strip */}
      <div className="mt-14 lg:mt-20 w-full">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.7, duration: 0.6 }}
          className="text-center text-stage-eyebrow text-white/45 mb-9 font-sans"
        >
          Presented by
        </motion.div>

        <div className="flex items-start justify-center gap-16 lg:gap-28">
          <CompactPresenterCard presenterId="romik" delay={1.9} />
          <CompactPresenterCard presenterId="jim" delay={2.1} />
        </div>
      </div>

      {/* Flynn dedication — micro, bottom-right; the TRON nod that
          frames the whole talk */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 0.4 }}
        transition={{ delay: 2.6, duration: 1.4 }}
        className="absolute bottom-6 right-8 max-w-md text-right z-10 hidden lg:block pointer-events-none"
      >
        <div className="text-[14px] font-mono text-white/55 italic leading-snug">
          "I kept dreaming of a world I thought I'd never see. And then,
          one day… I got in."
        </div>
        <div className="text-[11px] uppercase tracking-[0.3em] text-white/30 mt-2 font-sans">
          — Flynn · TRON
        </div>
      </motion.div>
    </div>
  )
}

// Bigger headshots and labels — readable from across the room.
function CompactPresenterCard({ presenterId, delay = 0 }) {
  const presenters = {
    romik: {
      name: 'Romik Hacobian',
      role: 'CEO · Media City Design',
      photo: '/assets/romik.jpg',
      logo: '/assets/mcd-logo.png',
      photoPos: 'center 25%'
    },
    jim: {
      name: 'Jim Festante',
      role: 'CEO · Healthe Habits',
      photo: '/assets/jim.jpg',
      logo: '/assets/healthe-logo.png',
      photoPos: 'center 30%'
    }
  }
  const p = presenters[presenterId]

  return (
    <motion.div
      initial={{ opacity: 0, y: 22 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
      className="flex flex-col items-center gap-4"
    >
      <div className="relative">
        <div className="absolute inset-[-12px] rounded-full bg-gradient-to-br from-accent-cyan/35 to-accent-indigo/25 blur-2xl" />
        <div className="absolute inset-[-3px] rounded-full bg-gradient-to-br from-accent-cyan via-accent-blue to-accent-indigo" />
        <div className="relative h-36 w-36 lg:h-40 lg:w-40 rounded-full overflow-hidden bg-ink-800 ring-2 ring-ink-950">
          <img
            src={p.photo}
            alt={p.name}
            className="h-full w-full object-cover"
            style={{ objectPosition: p.photoPos }}
          />
        </div>
      </div>

      <div className="text-center mt-2">
        <div className="font-sans display-sans text-[34px] lg:text-[38px] text-white leading-tight">{p.name}</div>
        <div className="text-[18px] lg:text-[20px] text-white/55 mt-1">{p.role}</div>
      </div>

      <div className="h-12 lg:h-14 flex items-center justify-center mt-1">
        <img
          src={p.logo}
          alt=""
          className="max-h-full max-w-[180px] lg:max-w-[200px] object-contain"
          style={{ filter: 'drop-shadow(0 4px 12px rgba(0,0,0,0.5))' }}
        />
      </div>
    </motion.div>
  )
}
