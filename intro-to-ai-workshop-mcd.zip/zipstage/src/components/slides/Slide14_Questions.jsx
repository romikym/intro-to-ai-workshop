import { useState } from 'react'
import { motion } from 'framer-motion'
import { MessageCircle, Sparkles, Wand2, MessageCircleQuestion, Calculator } from 'lucide-react'
import LiveChat from '../LiveChat'
import QRCode from '../effects/QRCode'
import AmbientParticles from '../effects/AmbientParticles'
import MagneticButton from '../effects/MagneticButton'
import PersonalizedStrategy from '../PersonalizedStrategy'
import AskQuestion from '../AskQuestion'
import ROICalculator from '../ROICalculator'

export default function Slide13_Questions() {
  const [chatOpen, setChatOpen] = useState(false)
  const [strategyOpen, setStrategyOpen] = useState(false)
  const [askOpen, setAskOpen] = useState(false)
  const [roiOpen, setRoiOpen] = useState(false)

  // QR encodes the URL with ?ask=1 so audience scans → lands here → ask modal opens directly
  const qrUrl = typeof window !== 'undefined'
    ? `${window.location.origin}${window.location.pathname}?ask=1`
    : undefined

  return (
    <>
      <div className="relative w-full h-full overflow-hidden">
        <AmbientParticles count={70} />

        <div className="relative w-full h-full flex items-center justify-center px-8 sm:px-12 py-10 lg:py-14 z-10">
          <div className="w-full max-w-[1500px] grid grid-cols-1 lg:grid-cols-[1.1fr_1fr] gap-10 lg:gap-16 items-center">
            {/* LEFT */}
            <div className="text-left">
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2, duration: 0.6 }}
                className="text-stage-eyebrow text-accent-cyan mb-6 font-sans"
              >
                Q&amp;A · Take-home
              </motion.div>

              <motion.h2
                initial={{ opacity: 0, scale: 0.96 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.4, duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
                className="font-sans display-sans leading-[0.9] mb-7 text-stage-h1"
              >
                <span className="gradient-text-bright">Questions</span>
                <span className="display-serif gradient-electric" style={{ fontStyle: 'italic' }}>?</span>
              </motion.h2>

              <motion.div
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.9, duration: 0.8 }}
                className="relative mb-9 max-w-2xl"
              >
                <div className="absolute -left-3 -top-7 font-serif text-[88px] text-accent-cyan/35 leading-none select-none">
                  &ldquo;
                </div>
                <blockquote className="display-serif text-[34px] lg:text-[40px] text-white/95 leading-tight pl-6" style={{ fontStyle: 'italic' }}>
                  AI won't replace you.
                  <span className="not-italic gradient-electric font-sans display-sans"> But someone using AI will.</span>
                </blockquote>
                <div className="text-stage-eyebrow text-white/45 mt-4 pl-6">
                  — ChatGPT
                </div>
              </motion.div>

              {/* Three CTAs — primary "Ask" highlighted */}
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1.4, duration: 0.7 }}
                className="space-y-3 mb-3"
              >
                {/* Primary: Ask a question */}
                <MagneticButton
                  onClick={() => setAskOpen(true)}
                  strength={0.2}
                  className="group relative inline-flex items-center gap-3 px-7 py-4 rounded-2xl bg-gradient-to-r from-accent-cyan to-accent-indigo text-white font-semibold shadow-2xl shadow-accent-cyan/20 hover:shadow-accent-cyan/40 transition-shadow w-full sm:w-auto"
                >
                  <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-accent-cyan to-accent-indigo blur-xl opacity-50 group-hover:opacity-80 transition-opacity -z-10" />
                  <MessageCircleQuestion className="h-6 w-6" />
                  <span className="text-2xl">Ask a question</span>
                  <div className="ml-2 px-2.5 py-1 rounded-full bg-white/20 text-xs uppercase tracking-wider font-bold">Live</div>
                </MagneticButton>

                {/* Secondary actions row */}
                <div className="flex flex-wrap gap-3">
                  <MagneticButton
                    onClick={() => setStrategyOpen(true)}
                    strength={0.18}
                    className="inline-flex items-center gap-2.5 px-5 py-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/15 hover:border-accent-cyan/40 text-white text-sm font-medium transition"
                  >
                    <Wand2 className="h-4 w-4" />
                    <span>Get your AI playbook</span>
                  </MagneticButton>

                  <MagneticButton
                    onClick={() => setRoiOpen(true)}
                    strength={0.18}
                    className="inline-flex items-center gap-2.5 px-5 py-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/15 hover:border-emerald-400/40 text-white text-sm font-medium transition"
                  >
                    <Calculator className="h-4 w-4" />
                    <span>What's AI worth to you?</span>
                  </MagneticButton>

                  <MagneticButton
                    onClick={() => setChatOpen(true)}
                    strength={0.18}
                    className="inline-flex items-center gap-2.5 px-5 py-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/15 hover:border-accent-cyan/40 text-white text-sm font-medium transition"
                  >
                    <MessageCircle className="h-4 w-4" />
                    <span>Chat with Claude</span>
                  </MagneticButton>
                </div>
              </motion.div>

              {/* Mini presenter strip */}
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1.9, duration: 0.7 }}
                className="flex items-center gap-8 mt-8 pt-5 border-t border-white/8"
              >
                <MiniPresenter
                  name="Romik Hacobian"
                  photo="/assets/romik.jpg"
                  logo="/assets/mcd-logo.png"
                  photoPos="center 25%"
                />
                <MiniPresenter
                  name="Jim Festante"
                  photo="/assets/jim.jpg"
                  logo="/assets/healthe-logo.png"
                  photoPos="center 30%"
                />
              </motion.div>
            </div>

            {/* RIGHT: QR */}
            <motion.div
              initial={{ opacity: 0, scale: 0.92 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.7, duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
              className="flex flex-col items-center"
            >
              <div className="text-xs uppercase tracking-[0.4em] text-accent-cyan/80 font-semibold mb-5 flex items-center gap-2">
                <Sparkles className="h-3.5 w-3.5" />
                Scan to ask a question
              </div>

              <QRCode
                size={240}
                value={qrUrl}
                label="Or take the deck home"
              />

              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 1.4, duration: 0.7 }}
                className="mt-6 max-w-xs text-center"
              >
                <div className="text-white/70 text-sm leading-relaxed">
                  Submit a question right from your phone — it'll appear on this screen instantly.
                </div>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </div>

      <LiveChat
        open={chatOpen}
        onClose={() => setChatOpen(false)}
        title="Open Q&A"
        subtitle="Ask anything — let's explore together"
        suggestedPrompts={[
          'Give me 3 specific ways a small Burbank business could use AI this week.',
          "What's one thing AI is genuinely bad at that humans should keep doing?",
          'Write a prompt I could use tomorrow to draft my next email newsletter.',
          'How do I write an "AI Philosophy" for a 5-person business?'
        ]}
        maxTokens={800}
      />

      <PersonalizedStrategy
        open={strategyOpen}
        onClose={() => setStrategyOpen(false)}
      />

      <AskQuestion open={askOpen} onClose={() => setAskOpen(false)} />
      <ROICalculator open={roiOpen} onClose={() => setRoiOpen(false)} />
    </>
  )
}

function MiniPresenter({ name, photo, logo, photoPos }) {
  return (
    <div className="flex items-center gap-3">
      <div className="relative shrink-0">
        <div className="absolute inset-[-1.5px] rounded-full bg-gradient-to-br from-accent-cyan to-accent-blue opacity-90" />
        <div className="relative h-12 w-12 rounded-full overflow-hidden bg-ink-800 ring-1 ring-ink-950">
          <img src={photo} alt={name} className="h-full w-full object-cover" style={{ objectPosition: photoPos }} />
        </div>
      </div>
      <div>
        <div className="font-serif text-base text-white/95 leading-tight">{name}</div>
        <div className="h-5 mt-1 flex items-center">
          <img
            src={logo}
            alt=""
            className="max-h-full max-w-[100px] object-contain"
            style={{ filter: 'drop-shadow(0 2px 4px rgba(0,0,0,0.4))' }}
          />
        </div>
      </div>
    </div>
  )
}
