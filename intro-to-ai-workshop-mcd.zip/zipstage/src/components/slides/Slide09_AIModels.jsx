import { useState } from 'react'
import { motion } from 'framer-motion'
import { Sparkles, Play } from 'lucide-react'
import SlideFrame, { SlideHeader } from '../SlideFrame'
import LiveChat from '../LiveChat'
import Card3D from '../effects/Card3D'
import MagneticButton from '../effects/MagneticButton'
import ScanningBorder from '../effects/ScanningBorder'

const models = [
  {
    company: 'Anthropic',
    name: 'Claude',
    bestFor: 'Drafting proposals, analyzing contracts, working through complex problems.',
    accent: 'from-orange-400/20 to-amber-500/10',
    text: 'text-orange-200',
    feature: true
  },
  {
    company: 'OpenAI',
    name: 'ChatGPT',
    bestFor: 'Most everyday tasks, brainstorming, plus DALL-E images and a huge plugin ecosystem.',
    accent: 'from-emerald-400/20 to-teal-500/10',
    text: 'text-emerald-200'
  },
  {
    company: 'Google',
    name: 'Gemini',
    bestFor: 'Drafting in Docs, summarizing Gmail threads, working with Sheets data.',
    accent: 'from-blue-400/20 to-sky-500/10',
    text: 'text-blue-200'
  },
  {
    company: 'Microsoft',
    name: 'Copilot',
    bestFor: 'Excel formulas, PowerPoint generation, Outlook replies, Teams meeting recap.',
    accent: 'from-cyan-400/20 to-blue-500/10',
    text: 'text-cyan-200'
  },
  {
    company: 'Perplexity',
    name: 'Perplexity',
    bestFor: 'Fact-checking, market research, anything where "where did this come from" matters.',
    accent: 'from-violet-400/20 to-indigo-500/10',
    text: 'text-violet-200'
  }
]

export default function Slide09_AIModels() {
  const [chatOpen, setChatOpen] = useState(false)

  return (
    <>
      <SlideFrame>
        <SlideHeader
          eyebrow="Meet the Major AI Models"
          title="They all do most things."
          presenter="romik"
        />

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4, duration: 0.6 }}
          className="text-white/65 text-xl lg:text-2xl mb-12 -mt-6 max-w-4xl leading-relaxed"
        >
          The differences are in personality, integration, and what each is truly best at.
        </motion.p>

        {/* Model cards */}
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-4 lg:gap-5 mb-12">
          {models.map((m, i) => (
            <motion.div
              key={m.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 + i * 0.08, duration: 0.6 }}
            >
              <Card3D intensity={0.9} className="rounded-2xl">
                {m.feature ? (
                  /* Featured Claude card with scanning border */
                  <div className="relative rounded-2xl overflow-hidden">
                    <ScanningBorder color1="#FB923C" color2="#22D3EE" duration={5} />
                    <div className={`relative m-[2px] rounded-2xl p-6 bg-gradient-to-br ${m.accent} backdrop-blur-sm`}>
                      <FeatureBadge />
                      <div className="text-xs uppercase tracking-[0.2em] text-white/55 mb-2 font-semibold">
                        {m.company}
                      </div>
                      <div className={`font-serif text-3xl mb-4 ${m.text}`}>{m.name}</div>
                      <div className="text-sm lg:text-base text-white/70 leading-relaxed">
                        <span className="text-white/45">Best for:</span> {m.bestFor}
                      </div>
                    </div>
                  </div>
                ) : (
                  /* Standard model card */
                  <div className={`relative rounded-2xl p-6 border border-white/10 bg-gradient-to-br ${m.accent} backdrop-blur-sm overflow-hidden`}>
                    <div className="text-xs uppercase tracking-[0.2em] text-white/55 mb-2 font-semibold">
                      {m.company}
                    </div>
                    <div className={`font-serif text-3xl mb-4 ${m.text}`}>{m.name}</div>
                    <div className="text-sm lg:text-base text-white/70 leading-relaxed">
                      <span className="text-white/45">Best for:</span> {m.bestFor}
                    </div>
                  </div>
                )}
              </Card3D>
            </motion.div>
          ))}
        </div>

        {/* Live demo CTA — magnetic */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.0, duration: 0.7 }}
          className="flex items-center justify-center"
        >
          <MagneticButton
            onClick={() => setChatOpen(true)}
            strength={0.25}
            className="group relative inline-flex items-center gap-3 px-9 py-5 rounded-2xl bg-gradient-to-r from-accent-cyan to-accent-indigo text-white font-medium shadow-2xl shadow-accent-cyan/20 hover:shadow-accent-cyan/40 hover:scale-105 transition-shadow"
          >
            <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-accent-cyan to-accent-indigo blur-xl opacity-50 group-hover:opacity-80 transition-opacity -z-10" />
            <Play className="h-5 w-5 fill-white" />
            <span className="text-xl">Try a live demo with Claude</span>
            <Sparkles className="h-5 w-5 opacity-70" />
          </MagneticButton>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.4, duration: 0.6 }}
          className="text-center mt-6 text-base text-white/45 italic font-serif"
        >
          Audience suggestion welcome — type whatever you want.
        </motion.div>
      </SlideFrame>

      <LiveChat
        open={chatOpen}
        onClose={() => setChatOpen(false)}
        title="Live Demo"
        subtitle="Type a prompt — Claude will respond in real time"
        suggestedPrompts={[
          'Write a friendly text reminder for a 9am Burbank dental appointment tomorrow.',
          'Draft a 2-sentence Yelp reply to a 4-star review of a Burbank pizza shop.',
          'Explain "machine learning" to a small business owner in 3 short sentences.',
          'Brainstorm 5 Instagram post ideas for a Burbank coffee shop celebrating an anniversary.'
        ]}
      />
    </>
  )
}

function FeatureBadge() {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay: 1.0, duration: 0.5 }}
      className="absolute top-3 right-3 text-[10px] uppercase tracking-[0.15em] text-orange-200 font-bold bg-orange-400/20 backdrop-blur-sm px-2 py-1 rounded flex items-center gap-1"
    >
      <span className="h-1.5 w-1.5 rounded-full bg-orange-300 animate-pulse" />
      Live Demo
    </motion.div>
  )
}
