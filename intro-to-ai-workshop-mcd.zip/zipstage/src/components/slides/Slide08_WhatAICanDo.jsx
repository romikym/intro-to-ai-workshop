import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { X } from 'lucide-react'
import SlideFrame, { SlideHeader } from '../SlideFrame'
import PillarCard from '../effects/PillarCard'

const categories = [
  {
    n: '01',
    pillLabel: 'Communication',
    title: 'Talk to customers',
    tagline: 'Reply with your voice, at machine speed.',
    body: 'Drafts emails, FAQ answers, support replies, and review responses — in your tone, every time.',
    checklist: ['Yelp & review replies', 'Email & FAQ drafts'],
    theme: 'cyan',
    examplePrompt: 'Reply to this 2-star Yelp review about a cold pizza, in a warm Burbank-local tone, owner-signed.'
  },
  {
    n: '02',
    pillLabel: 'Marketing',
    title: 'Make content',
    tagline: 'One idea, ten formats.',
    body: 'Social posts, blog drafts, ad copy, newsletters — turn one idea into a week of content.',
    checklist: ['Social & email', 'Ad variations'],
    theme: 'amber',
    examplePrompt: 'Take this product launch and make: an Instagram post, a LinkedIn post, an email subject line, and 3 ad headlines.'
  },
  {
    n: '03',
    pillLabel: 'Operations',
    title: 'Run the office',
    tagline: 'Less paperwork, more business.',
    body: 'Summarizes meetings, organizes notes, turns rough thoughts into clean documents.',
    checklist: ['Meeting recaps', 'Cleaned-up docs'],
    theme: 'emerald',
    examplePrompt: 'Here is my 45-minute meeting transcript. Give me decisions made, action items by owner, and a 3-sentence summary.'
  },
  {
    n: '04',
    pillLabel: 'Research',
    title: 'Know your market',
    tagline: 'Read what you do not have time to read.',
    body: 'Competitor scans, market research, reading long PDFs and giving you the gist in minutes.',
    checklist: ['Competitor scans', 'Long PDFs digested'],
    theme: 'sky',
    examplePrompt: 'Read these 6 competitor websites. What do they all promise? What do they all leave out? Where is the opening?'
  },
  {
    n: '05',
    pillLabel: 'Design',
    title: 'Make visuals',
    tagline: 'A designer in your pocket.',
    body: 'Generates images, mockups, social graphics, even short video clips — visual work without a designer.',
    checklist: ['Social graphics', 'Quick mockups'],
    theme: 'violet',
    examplePrompt: 'Generate 4 hero image options for a Burbank dental office homepage — warm, family-friendly, no stock-photo clichés.'
  },
  {
    n: '06',
    pillLabel: 'Decisions',
    title: 'Read the numbers',
    tagline: 'Patterns you would otherwise miss.',
    body: 'Reads your sales data, suggests pricing, surfaces trends — like having an analyst on call.',
    checklist: ['Sales patterns', 'Pricing & bundles'],
    theme: 'rose',
    examplePrompt: 'Here is 12 months of sales data. Which days are dead? What product moves on Tuesdays vs Saturdays? What should I bundle?'
  }
]

export default function Slide08_WhatAICanDo() {
  const [activeIdx, setActiveIdx] = useState(null)

  return (
    <>
      <SlideFrame>
        <SlideHeader
          eyebrow="What AI Can Do"
          title="Six concrete categories."
          presenter="romik"
        />

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 lg:gap-6 flex-1 content-start">
          {categories.map((c, i) => (
            <PillarCard
              key={c.n}
              number={c.n}
              pillLabel={c.pillLabel}
              title={c.title}
              tagline={c.tagline}
              checklist={c.checklist}
              theme={c.theme}
              size="sm"
              delay={0.3 + i * 0.08}
              cta="See an example prompt"
              onClick={() => setActiveIdx(i)}
            />
          ))}
        </div>
      </SlideFrame>

      <AnimatePresence>
        {activeIdx !== null && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-8"
          >
            <div className="absolute inset-0 bg-ink-950/85 backdrop-blur-md" onClick={() => setActiveIdx(null)} />

            <motion.div
              initial={{ scale: 0.95, y: 30, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.95, y: 30, opacity: 0 }}
              transition={{ type: 'spring', stiffness: 260, damping: 28 }}
              className="relative glass-strong rounded-3xl w-full max-w-2xl overflow-hidden"
            >
              <div className="px-8 py-6 border-b border-white/8 flex items-start justify-between">
                <div>
                  <div className="text-xs uppercase tracking-[0.25em] text-accent-cyan font-semibold mb-2">
                    {categories[activeIdx].pillLabel}
                  </div>
                  <h3 className="font-serif text-3xl text-white leading-tight">
                    {categories[activeIdx].title}
                  </h3>
                </div>
                <button
                  onClick={() => setActiveIdx(null)}
                  className="h-10 w-10 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center transition shrink-0"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
              <div className="px-8 py-7">
                <div className="text-xs uppercase tracking-[0.2em] text-white/50 mb-3 font-semibold">
                  Try this prompt
                </div>
                <div className="bg-black/30 border border-white/10 rounded-xl p-5 font-mono text-base text-white/95 leading-relaxed">
                  "{categories[activeIdx].examplePrompt}"
                </div>
                <div className="text-sm text-white/50 mt-4 italic font-serif">
                  Copy → paste into Claude or ChatGPT → fill in your own details.
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
