import { motion } from 'framer-motion'
import AmbientParticles from '../effects/AmbientParticles'
import PillarCard from '../effects/PillarCard'

const pillars = [
  {
    n: '01',
    pillLabel: 'Pillar 01',
    title: 'Tools',
    tagline: 'What AI can actually do.',
    body: 'Six concrete categories where small businesses are getting real value today — not next year.',
    theme: 'cyan'
  },
  {
    n: '02',
    pillLabel: 'Pillar 02',
    title: 'Models',
    tagline: 'The major AI tools.',
    body: 'Claude, ChatGPT, Gemini, Copilot, Perplexity — and what each is best for.',
    theme: 'sky'
  },
  {
    n: '03',
    pillLabel: 'Pillar 03',
    title: 'Use Cases',
    tagline: 'Real businesses, real wins.',
    body: 'Restaurants, retail, services, coaches — what is working right now.',
    theme: 'violet'
  },
  {
    n: '04',
    pillLabel: 'Pillar 04',
    title: 'Action',
    tagline: 'Start this week.',
    body: 'A simple 5-step plan to put AI to work in your business by Friday.',
    theme: 'rose'
  }
]

export default function Slide07_AIForSmallBusiness() {
  return (
    <div className="relative w-full h-full overflow-hidden">
      <AmbientParticles count={50} />

      <div className="relative w-full h-full flex flex-col items-center justify-center px-10 sm:px-16 py-10 z-10">
        <div className="w-full max-w-[1500px]">
          {/* Eyebrow with elegant divider */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3, duration: 0.7 }}
            className="text-center mb-6"
          >
            <div className="inline-flex items-center gap-3 text-sm uppercase tracking-[0.4em] text-accent-cyan font-semibold">
              <span className="h-px w-12 bg-gradient-to-r from-transparent to-accent-cyan/60" />
              Part Two — Romik Hacobian
              <span className="h-px w-12 bg-gradient-to-l from-transparent to-accent-cyan/60" />
            </div>
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 30, filter: 'blur(8px)' }}
            animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
            transition={{ delay: 0.5, duration: 1.0, ease: [0.22, 1, 0.36, 1] }}
            className="font-serif text-center mb-3 leading-[0.95] tracking-tight"
            style={{ fontSize: 'clamp(3.5rem, 8vw, 6.5rem)' }}
          >
            AI for <em className="gradient-text">Small Business.</em>
          </motion.h2>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.0, duration: 0.7 }}
            className="text-center text-white/65 text-lg lg:text-xl mb-12 max-w-3xl mx-auto"
          >
            Where to start, what tools to use, and how to make AI useful by Friday.
          </motion.p>

          {/* 4 PillarCards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 lg:gap-6">
            {pillars.map((p, i) => (
              <PillarCard
                key={p.n}
                number={p.n}
                pillLabel={p.pillLabel}
                title={p.title}
                tagline={p.tagline}
                body={p.body}
                theme={p.theme}
                size="sm"
                delay={1.3 + i * 0.13}
                showArrow={false}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
