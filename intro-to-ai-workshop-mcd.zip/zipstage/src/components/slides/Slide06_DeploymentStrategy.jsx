import { motion } from 'framer-motion'
import { FileText, CheckCircle2, AlertCircle } from 'lucide-react'
import SlideFrame, { SlideHeader } from '../SlideFrame'

export default function Slide06_DeploymentStrategy() {
  return (
    <SlideFrame>
      <SlideHeader
        eyebrow="Deployment Strategy"
        title="One page first."
        presenter="jim"
      />

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_1.1fr] gap-12 lg:gap-16 flex-1 items-center">
        {/* Argument */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.4, duration: 0.7 }}
          className="space-y-8"
        >
          <div className="font-serif text-3xl lg:text-4xl xl:text-5xl text-white/95 leading-tight">
            Do not buy a single AI license <em className="gradient-text">until</em> you have written a one-page <strong className="font-serif italic">AI Philosophy</strong> for your staff.
          </div>

          <div className="space-y-5 pt-3">
            <div className="flex items-start gap-4">
              <CheckCircle2 className="h-6 w-6 text-accent-cyan mt-1 shrink-0" />
              <div>
                <div className="font-medium text-white/95 text-xl">Define what AI is allowed to do</div>
                <div className="text-base text-white/60 mt-1.5">Specific tasks, specific tools, specific outputs.</div>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <AlertCircle className="h-6 w-6 text-accent-blue mt-1 shrink-0" />
              <div>
                <div className="font-medium text-white/95 text-xl">Define where humans stay in the loop</div>
                <div className="text-base text-white/60 mt-1.5">Client communication, contracts, anything with brand or legal exposure.</div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Document mockup */}
        <motion.div
          initial={{ opacity: 0, x: 20, rotate: 0 }}
          animate={{ opacity: 1, x: 0, rotate: 1.5 }}
          transition={{ delay: 0.6, duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
          className="relative"
        >
          <div className="absolute inset-0 bg-gradient-to-br from-accent-cyan/20 to-accent-indigo/10 blur-3xl rounded-full" />
          <div className="relative glass-strong rounded-2xl p-8 lg:p-10 border border-white/15 max-w-md mx-auto">
            {/* Doc header */}
            <div className="flex items-center gap-3 pb-5 border-b border-white/10 mb-6">
              <div className="h-11 w-11 rounded-lg bg-gradient-to-br from-accent-cyan/20 to-accent-blue/10 border border-accent-cyan/20 flex items-center justify-center">
                <FileText className="h-5 w-5 text-accent-cyan" />
              </div>
              <div>
                <div className="text-xs uppercase tracking-[0.2em] text-white/45">Internal Policy</div>
                <div className="font-serif text-2xl text-white/95 leading-tight">AI Philosophy</div>
              </div>
            </div>

            <DocLines />

            <div className="mt-6 pt-5 border-t border-white/10 text-sm text-white/45 italic font-serif">
              One page. Approved before any tool is purchased.
            </div>
          </div>
        </motion.div>
      </div>
    </SlideFrame>
  )
}

function DocLines() {
  const sections = [
    { title: 'Allowed', items: [
      'Drafting internal documentation',
      'Summarizing meeting transcripts',
      'Brainstorming ideas (with human edit)'
    ]},
    { title: 'Requires Human Review', items: [
      'Customer-facing communication',
      'Marketing copy & brand voice',
      'Any external-facing content'
    ]},
    { title: 'Prohibited', items: [
      'Legal documents & contracts',
      'Financial decisions',
      'Confidential client data'
    ]}
  ]

  return (
    <div className="space-y-5">
      {sections.map((section, i) => (
        <motion.div
          key={section.title}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.0 + i * 0.2, duration: 0.5 }}
        >
          <div className="text-xs uppercase tracking-[0.25em] text-accent-cyan/80 font-semibold mb-2.5">
            {section.title}
          </div>
          <div className="space-y-2">
            {section.items.map((item, j) => (
              <div key={j} className="flex gap-2.5 text-base text-white/70">
                <span className="text-white/30">·</span>
                <span>{item}</span>
              </div>
            ))}
          </div>
        </motion.div>
      ))}
    </div>
  )
}
