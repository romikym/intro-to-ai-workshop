import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'

const EXAMPLES = [
  {
    prompt: 'The cat sat on the',
    predictions: [
      { token: ' mat', prob: 0.42 },
      { token: ' couch', prob: 0.18 },
      { token: ' floor', prob: 0.11 },
      { token: ' bed', prob: 0.08 },
      { token: ' chair', prob: 0.06 }
    ]
  },
  {
    prompt: 'Burbank is famous for',
    predictions: [
      { token: ' its', prob: 0.31 },
      { token: ' the', prob: 0.22 },
      { token: ' being', prob: 0.14 },
      { token: ' Warner', prob: 0.09 },
      { token: ' media', prob: 0.07 }
    ]
  },
  {
    prompt: 'The customer wanted a refund because',
    predictions: [
      { token: ' the', prob: 0.38 },
      { token: ' they', prob: 0.21 },
      { token: ' he', prob: 0.11 },
      { token: ' she', prob: 0.10 },
      { token: ' it', prob: 0.07 }
    ]
  }
]

export default function TokenPrediction() {
  const [exampleIdx, setExampleIdx] = useState(0)
  const [stage, setStage] = useState('typing')

  const example = EXAMPLES[exampleIdx]
  const top = example.predictions[0]

  useEffect(() => {
    setStage('typing')
    const t1 = setTimeout(() => setStage('predicting'), 1200)
    const t2 = setTimeout(() => setStage('revealed'), 2400)
    return () => { clearTimeout(t1); clearTimeout(t2) }
  }, [exampleIdx])

  useEffect(() => {
    const t = setTimeout(() => {
      setExampleIdx((i) => (i + 1) % EXAMPLES.length)
    }, 6500)
    return () => clearTimeout(t)
  }, [exampleIdx])

  return (
    <div className="w-full">
      {/* Prompt + predicted token */}
      <div className="font-mono text-2xl sm:text-3xl lg:text-4xl leading-relaxed mb-10 min-h-[3em] flex items-center flex-wrap">
        <span className="text-white/90">{example.prompt}</span>
        <AnimatePresence mode="wait">
          {stage !== 'typing' && (
            <motion.span
              key={`${exampleIdx}-${stage}`}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.4 }}
              className="gradient-text font-semibold"
            >
              {top.token}
            </motion.span>
          )}
        </AnimatePresence>
        {stage === 'typing' && <span className="caret text-white/85"></span>}
      </div>

      {/* Probability bars */}
      <div className="space-y-4">
        <div className="text-sm uppercase tracking-[0.25em] text-white/50 mb-5 font-semibold">
          Next-token probability
        </div>
        {example.predictions.map((pred, i) => {
          const isWinner = i === 0
          const visible = stage !== 'typing'
          return (
            <motion.div
              key={`${exampleIdx}-${pred.token}`}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: visible ? 1 : 0, x: visible ? 0 : -10 }}
              transition={{ delay: visible ? i * 0.08 : 0, duration: 0.4 }}
              className="flex items-center gap-4 lg:gap-5"
            >
              <div className="font-mono text-base lg:text-lg w-32 lg:w-40 text-right text-white/85 shrink-0">
                "{pred.token.trim()}"
              </div>
              <div className="flex-1 h-3 bg-white/5 rounded-full overflow-hidden">
                <motion.div
                  className={`h-full rounded-full ${
                    isWinner
                      ? 'bg-gradient-to-r from-accent-cyan to-accent-blue'
                      : 'bg-white/20'
                  }`}
                  initial={{ width: 0 }}
                  animate={{ width: visible ? `${pred.prob * 100}%` : 0 }}
                  transition={{ delay: visible ? 0.3 + i * 0.08 : 0, duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
                />
              </div>
              <div className="font-mono text-base lg:text-lg w-16 text-white/65 tabular-nums">
                {(pred.prob * 100).toFixed(0)}%
              </div>
            </motion.div>
          )
        })}
      </div>

      {/* Caption */}
      <motion.div
        className="mt-10 text-base lg:text-lg text-white/60 leading-relaxed max-w-xl"
        initial={{ opacity: 0 }}
        animate={{ opacity: stage === 'revealed' ? 1 : 0 }}
        transition={{ duration: 0.5 }}
      >
        It does not "know" the answer. It predicts the next most statistically likely token, every time. This is why average output is the default.
      </motion.div>

      {/* Example dots */}
      <div className="flex gap-2.5 mt-8">
        {EXAMPLES.map((_, i) => (
          <button
            key={i}
            onClick={() => setExampleIdx(i)}
            className={`h-2 rounded-full transition-all ${
              i === exampleIdx ? 'w-10 bg-accent-cyan' : 'w-2 bg-white/20 hover:bg-white/40'
            }`}
            aria-label={`Example ${i + 1}`}
          />
        ))}
      </div>
    </div>
  )
}
