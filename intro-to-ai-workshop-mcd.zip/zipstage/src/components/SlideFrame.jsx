import { motion } from 'framer-motion'
import { PresenterChip } from './Presenters'

/**
 * Slide layout — eyebrow + title + presenter chip across the top, content
 * beneath. Sizing tuned for 20-foot readability on a 1080p TV.
 */
export function SlideHeader({ eyebrow, title, presenter, align = 'left' }) {
  return (
    <div className={`flex items-start ${align === 'center' ? 'justify-center text-center' : 'justify-between'} mb-7 sm:mb-9 lg:mb-12 gap-6`}>
      <motion.div
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
        className={`flex-1 min-w-0 ${align === 'center' ? 'text-center' : ''}`}
      >
        {eyebrow && (
          <div className="text-stage-eyebrow text-accent-cyan mb-4 sm:mb-5 font-sans">
            {eyebrow}
          </div>
        )}
        <h2 className="font-sans display-sans text-stage-h2 gradient-text-bright">
          {title}
        </h2>
      </motion.div>

      {presenter && align !== 'center' && <PresenterChip presenterId={presenter} />}
    </div>
  )
}

export default function SlideFrame({ children, className = '' }) {
  return (
    <div className={`w-full min-h-full flex flex-col px-7 sm:px-14 lg:px-20 py-10 sm:py-14 lg:py-16 ${className}`}>
      <div className="w-full max-w-[1440px] mx-auto flex-1 flex flex-col">
        {children}
      </div>
    </div>
  )
}

export function PointCard({ children, delay = 0, accent = false }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 22 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
      className={`relative ${
        accent
          ? 'gradient-border p-9 lg:p-12'
          : 'glass rounded-2xl p-8 lg:p-11 border border-white/10 hover:border-white/20 transition'
      }`}
    >
      {children}
    </motion.div>
  )
}

export function Accent({ children, gradient = 'electric' }) {
  const cls = gradient === 'sunset' ? 'gradient-sunset' : 'gradient-electric'
  return (
    <em className={`display-serif ${cls}`} style={{ fontStyle: 'italic' }}>
      {children}
    </em>
  )
}
