import { motion } from 'framer-motion'
import { ArrowUpRight, Check } from 'lucide-react'
import GradientMesh, { THEMES } from './GradientMesh'

/**
 * PillarCard — the signature card style across the deck, modeled on
 * Media City Design's website pillar cards.
 *
 * Layout:
 *   [number]    [arrow]
 *      gradient mesh
 *      [pill badge]
 *      [Big Bold Title]
 *   ──────────────
 *   italic serif tagline
 *   body paragraph
 *   ✓ checklist
 *   CTA →
 */
export default function PillarCard({
  number,
  pillLabel,
  title,
  tagline,
  body,
  checklist = [],
  cta,
  onClick,
  theme = 'cyan',
  delay = 0,
  size = 'md', // 'sm' | 'md' | 'lg'
  showArrow = true
}) {
  const config = THEMES[theme] || THEMES.cyan

  // Size variations — tuned for fitting 6-card grids on desktop, natural flow on mobile
  const sizes = {
    sm: {
      headerH: 'h-28 sm:h-30 lg:h-32',
      titleSize: 'text-xl sm:text-2xl lg:text-2xl',
      taglineSize: 'text-sm lg:text-base',
      bodySize: 'text-sm lg:text-sm',
      pad: 'p-4 lg:p-5'
    },
    md: {
      headerH: 'h-36 sm:h-44 lg:h-48',
      titleSize: 'text-3xl sm:text-4xl lg:text-4xl',
      taglineSize: 'text-base sm:text-lg lg:text-xl',
      bodySize: 'text-sm sm:text-base lg:text-base',
      pad: 'p-5 sm:p-6'
    },
    lg: {
      headerH: 'h-44 sm:h-52 lg:h-60',
      titleSize: 'text-4xl sm:text-5xl lg:text-6xl',
      taglineSize: 'text-lg sm:text-xl lg:text-2xl',
      bodySize: 'text-base sm:text-lg',
      pad: 'p-6 sm:p-7'
    }
  }[size]

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
      onClick={onClick}
      className={`group relative rounded-3xl overflow-hidden bg-ink-900/50 backdrop-blur-sm border border-white/8 hover:border-white/20 transition-all ${onClick ? 'cursor-pointer' : ''} h-full flex flex-col`}
      whileHover={{ y: -4 }}
    >
      {/* Top: gradient mesh header */}
      <div className={`relative ${sizes.headerH} overflow-hidden`}>
        <GradientMesh theme={theme} className="absolute inset-0" animate />

        {/* Number indicator top-left */}
        {number && (
          <div className="absolute top-4 left-4 z-10">
            <div className="h-11 w-11 rounded-xl bg-black/30 backdrop-blur-md border border-white/15 flex items-center justify-center font-mono text-sm font-bold text-white">
              {number}
            </div>
          </div>
        )}

        {/* Arrow indicator top-right */}
        {showArrow && (
          <div className="absolute top-4 right-4 z-10">
            <motion.div
              className="h-11 w-11 rounded-xl bg-black/30 backdrop-blur-md border border-white/15 flex items-center justify-center"
              whileHover={{ rotate: -45 }}
              transition={{ type: 'spring', stiffness: 300 }}
            >
              <ArrowUpRight className="h-5 w-5 text-white group-hover:scale-110 transition-transform" />
            </motion.div>
          </div>
        )}

        {/* Pill badge near bottom-left of header */}
        {pillLabel && (
          <div className="absolute bottom-16 left-5 lg:left-6 z-10">
            <div
              className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full backdrop-blur-md text-xs uppercase tracking-[0.15em] font-bold text-white"
              style={{ background: `${config.pillColor}` }}
            >
              <span className="h-1.5 w-1.5 rounded-full bg-white" />
              {pillLabel}
            </div>
          </div>
        )}

        {/* Big bold title in white */}
        {title && (
          <h3
            className={`absolute bottom-5 left-5 lg:left-6 right-16 z-10 text-white font-black ${sizes.titleSize} tracking-tight leading-[0.9]`}
            style={{
              fontFamily: '"Inter Tight", system-ui, sans-serif',
              fontWeight: 900,
              textShadow: '0 2px 20px rgba(0,0,0,0.3)'
            }}
          >
            {title}
          </h3>
        )}
      </div>

      {/* Bottom: content */}
      <div className={`flex-1 flex flex-col ${sizes.pad}`}>
        {tagline && (
          <div
            className={`font-serif italic ${sizes.taglineSize} text-white/95 leading-snug mb-2`}
          >
            {tagline}
          </div>
        )}

        {body && (
          <p className={`${sizes.bodySize} text-white/65 leading-relaxed mb-4`}>
            {body}
          </p>
        )}

        {checklist.length > 0 && (
          <ul className="space-y-2 mb-3">
            {checklist.map((item, i) => (
              <motion.li
                key={i}
                initial={{ opacity: 0, x: -8 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: delay + 0.4 + i * 0.08, duration: 0.4 }}
                className="flex items-start gap-2.5"
              >
                <div
                  className="h-5 w-5 rounded-full flex items-center justify-center shrink-0 mt-0.5"
                  style={{
                    backgroundColor: `${config.pillColor}25`,
                    border: `1px solid ${config.pillColor}50`
                  }}
                >
                  <Check className="h-3 w-3" style={{ color: config.accent }} strokeWidth={3} />
                </div>
                <span className="text-white/85 text-sm lg:text-base leading-snug">{item}</span>
              </motion.li>
            ))}
          </ul>
        )}

        {cta && (
          <div className="mt-auto pt-3 border-t border-white/8">
            <div
              className="inline-flex items-center gap-2 font-semibold text-sm group-hover:gap-3 transition-all"
              style={{ color: config.accent }}
            >
              {cta}
              <span className="transition-transform group-hover:translate-x-1">→</span>
            </div>
          </div>
        )}
      </div>
    </motion.div>
  )
}
