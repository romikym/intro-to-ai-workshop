/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      fontFamily: {
        // Display serif from Media City Design — italic accent for headline words
        serif: ['"Fraunces"', '"Instrument Serif"', 'serif'],
        sans: ['"Inter Tight"', 'system-ui', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'monospace']
      },
      colors: {
        // Cinematic dark surfaces, ported from mediacitydesign.com hero
        ink: {
          950: '#07060F',
          900: '#0A0820',
          800: '#0E0C20',
          700: '#1A1730',
          600: '#2A2548'
        },
        // MCD electric palette — TRON-derived
        accent: {
          // Primary electric blue — the workhorse
          cyan: '#2997FF',
          blue: '#5FB6FF',
          indigo: '#C064F0',
          violet: '#8E4EC6',
          amber: '#F5A623',
          gold: '#FFB84D',
          teal: '#00C7BE',
          coral: '#FF375F'
        }
      },
      animation: {
        'fade-up': 'fadeUp 0.8s cubic-bezier(0.22, 1, 0.36, 1) forwards',
        'pulse-slow': 'pulse 4s cubic-bezier(0.4, 0, 0.6, 1